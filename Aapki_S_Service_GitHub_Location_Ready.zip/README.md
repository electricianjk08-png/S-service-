# Aapki S Service — GitHub-ready files

- `customer.html`: customer registration/login, service booking, tracking and optional GPS location capture.
- `owner.html`: private owner portal for booking management, technician authorization, charges and work status.
- `style.css`: responsive design.
- `app.js`: Firebase logic and GPS/map links.
- `firebase.js`: Firebase web configuration placeholders.
- `firestore.rules`: Firestore security rules.

## Location
Customer can tap **Use my current location** and allow browser location permission. Coordinates are saved with booking; owner/staff can open them in Google Maps. GPS is optional; typed address still works. Geolocation requires HTTPS and permission.

## Setup
1. Create Firebase project and register a Web app.
2. Enable Email/Password in Firebase Authentication.
3. Create Firestore Database and publish `firestore.rules`.
4. Replace placeholders in `firebase.js` with Firebase web config.
5. Create owner account in Firebase Authentication, then create Firestore document `users/{AUTH_UID}` with fields `uid`, `email`, `name`, and `role: "owner"`.
6. Upload these files to GitHub. Enable Settings > Pages.
7. Rename `customer.html` to `index.html` if you want the customer page to open as the GitHub Pages homepage. Keep `owner.html` as the separate portal.

Never upload Firebase Admin service-account keys. Keep security rules enabled and test before sharing.
